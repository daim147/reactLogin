import React from "react";

export const Inputs = (props) => {
  return (
    <input
      type={props.type}
      required
      onChange={(e) => props.handler && props.handler(e.target.value)}
      placeholder={props.placeholder}
    />
  );
};
