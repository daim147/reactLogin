import React from "react";
import { Form } from "./form";
import { Greeting } from "./greeting";
class App extends React.Component {
  state = {
    name: "",
    islogged: true,
    isRegistered: false,
    password: "",
    hour: new Date().getHours(),
    type: "Registered",
    canRegistered: false
  };
  setName = (value) => {
    this.setState({ name: value });
  };
  logged = () => {
    this.setState({ islogged: !this.state.islogged });
  };
  password = (value, check = false) => {
    this.setState({ password: value });
    if (check && value === this.state.password) {
      this.setState({ canRegistered: true });
    }
  };
  render() {
    return (
      <div className="container">
        <h1>Hello {this.state.name}</h1>
        {this.state.islogged ? (
          <Form
            handler={this.setName}
            logged={this.logged}
            password={this.password}
            data={this.state}
          />
        ) : (
          <Greeting hour={this.state.hour} />
        )}
      </div>
    );
  }
}
export default App;
