import React from "react";
import { Inputs } from "./inputs";
export const Form = (props) => {
  return (
    <form className="form">
      <Inputs type="text" handler={props.handler} placeholder="Username" />
      <Inputs type="password" placeholder="Password" handler={props.password} />
      !props.data.isRegistered && <Inputs />
      <button
        onClick={(e) => {
          e.preventDefault();
          props.logged();
        }}
        type={props.type}
      >
        {props.data.type}
      </button>
    </form>
  );
};
